package com.crm.qa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.crm.qa.base.TestBase;

public class checkout_page extends TestBase{
	@FindBy(xpath = "(//input[@type='email' and @name='username' and @class='input-text'])[1]")
	WebElement email_id;
	
	@FindBy(xpath="(//input[@name='firstname' and @class='input-text'])[1]")
	WebElement first_name;
	
	@FindBy(xpath="(//input[@name='lastname' and @class='input-text'])[1]")
	WebElement lastname;
	
	@FindBy(xpath="(//input[@name='street[0]' and @class='input-text'])[1]")
	WebElement street_add;
	
	@FindBy(xpath = "(//select[@name='country_id'])[1]")
	WebElement country;
	
	@FindBy(xpath = "(//input[@name='postcode'])[1]")
	WebElement postal_code;
	
	@FindBy(xpath = "(//input[@name='telephone'])[1]")
	WebElement phone_number;
	
	@FindBy(xpath = "(//input[@name='city' and @class='input-text'])[1]")
	WebElement city;
	
	@FindBy(xpath = "(//input[@name='cardnumber'])[1]")
	WebElement card_number;
	
	@FindBy(xpath = "(//input[@name='exp-date'])[1]")
	WebElement cvv;
	
	@FindBy(xpath = "//span[text()=' Place Order']")
	WebElement place_order;
	
	@FindBy(xpath = "//span[text()=' Place Order']")
	WebElement expire_date;
	// Initializing the Page Objects:
	public checkout_page() {
		PageFactory.initElements(driver, this);
	}
	
	
	public void select_colour(){
		Select colour = new Select(driver.findElement((By.xpath("//select[contains(@name, 'super_attribute')]"))));
		colour.selectByIndex(1);
		
	}
	
	
	public void Add_information(){
		
		email_id.sendKeys("someone@whocares.com");
		first_name.sendKeys("test");
		lastname.sendKeys("tester");
		street_add.sendKeys("omandante Izarduy 67");
		city.sendKeys("Barcelona");
		Select colour = new Select(driver.findElement((By.xpath("(//select[@name='country_id'])[1]"))));
		colour.selectByVisibleText("Spain");
		postal_code.sendKeys("08940");
		phone_number.sendKeys("5555555555");
		card_number.sendKeys("4111111111111111");
		
		cvv.sendKeys("222111");
	}
	
	
	public void place_order(){
		place_order.isDisplayed();
		place_order.click();
		
	}
	
	

}
