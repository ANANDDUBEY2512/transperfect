package com.crm.qa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.SendKeysAction;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.crm.qa.base.TestBase;

public class Shopping_Page extends TestBase {

	@FindBy(xpath = "//select[contains(@name, 'super_attribute')]")
	WebElement colour_dropdown;
	
	@FindBy(xpath="//button[@type]//span[contains(text(), 'Add to Cart')]")
	WebElement Add_to_Cart;
	
	@FindBy(xpath="//button[text()='Checkout']")
	WebElement checkout_button;
	
	@FindBy(xpath="//span[text()='OK']")
	WebElement Ok_button;
	
	@FindBy(xpath = "//span[text()='Remove']")
	WebElement remove_button;
	
	
	
	// Initializing the Page Objects:
	public Shopping_Page() {
		PageFactory.initElements(driver, this);
	}
	
	
	public void select_colour(){
		Select colour = new Select(driver.findElement((By.xpath("//select[contains(@name, 'super_attribute')]"))));
		colour.selectByIndex(1);
		
	}
	
	
	public void Addtocart(){
		
		
		if(driver.findElements(By.xpath("//span[text()='Color']")).size() != 0){
			System.out.println("Enter colour");
			select_colour();
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", Add_to_Cart);
			}
		else{
			System.out.println("No colour to enter");
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", Add_to_Cart);
			}
		
	
			
		}
		
	
	
	
	public void remove_from_cart(){
		remove_button.isDisplayed();
		remove_button.click();
		Ok_button.isDisplayed();
		Ok_button.click();
		
	}
	
	public void proceed_checkout() {
		checkout_button.isDisplayed();
		checkout_button.click();
	}
	

}
