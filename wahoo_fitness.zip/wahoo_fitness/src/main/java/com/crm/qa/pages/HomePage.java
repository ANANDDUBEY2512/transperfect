package com.crm.qa.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.crm.qa.base.TestBase;

public class HomePage extends TestBase {

	@FindBy(xpath = "//span[contains(text(),'SHOP')]")
	@CacheLookup
	static
	WebElement Shop_hyperlink;

	@FindBy(xpath = "(//h2[contains(text(),'All Products')]")
	static
	WebElement All_product;
	
	@FindBy(xpath = "//*[contains(@title,'Wahoo Fitness specializes in indoor bike trainer')]")
	static
	WebElement home_title;
	

	@FindBy(xpath = "//*[@class='product-name']")
	static
	WebElement product_list;

	@FindBy(xpath = "//a[contains(text(),'Tasks')]")
	WebElement tasksLink;

	// Initializing the Page Objects:
	public HomePage() {
		PageFactory.initElements(driver, this);
	}
	
	public  static void For_homepage_TO_AllProduct(){
		Shop_hyperlink.click();
		//All_product.isDisplayed();
	}
	
	
	public static void verify_homepage(){
		String title=home_title.getText();
		System.out.println(title);
	}
	
	public static void Select_random_product() throws InterruptedException{
		Thread.sleep(5000);
		List<WebElement> myElements = driver.findElements((By.xpath("//*[@class='product-name']")));
		WebElement random=myElements.get(0);
		random.click();
		
	}
	
	
	
	
	
	
	
	
	

}
