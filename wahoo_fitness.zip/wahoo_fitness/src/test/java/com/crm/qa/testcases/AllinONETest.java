package com.crm.qa.testcases;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.crm.qa.base.TestBase;
import com.crm.qa.pages.Shopping_Page;
import com.crm.qa.pages.HomePage;
import com.crm.qa.pages.checkout_page;
import com.crm.qa.util.TestUtil;

public class AllinONETest extends TestBase {
	checkout_page checkoutpage;
	HomePage homePage;
	TestUtil testUtil;
	Shopping_Page shoppingpage;

	public AllinONETest() {
		super();
	}

	//test cases should be separated -- independent with each other
	//before each test case -- launch the browser and login
	//@test -- execute test case
	//after each test case -- close the browser
	
	@BeforeMethod
	public void setUp() {
		initialization();
		testUtil = new TestUtil();
		checkoutpage = new checkout_page();
		shoppingpage = new Shopping_Page();
		homePage=new HomePage();
		
	}
	
	
	@Test(priority = 1)
	public void completedorder() throws InterruptedException{
		
		homePage.verify_homepage();
		
		homePage.For_homepage_TO_AllProduct();
		
		homePage.Select_random_product();
		Thread.sleep(3000);
		shoppingpage.Addtocart();
		Thread.sleep(3000);
		shoppingpage.proceed_checkout();
		checkoutpage.Add_information();
		checkoutpage.place_order();
		
	}
	
	@Test(priority = 2)
	public void removetfromcart() throws InterruptedException{
		
		homePage.verify_homepage();
		
		homePage.For_homepage_TO_AllProduct();
		
		homePage.Select_random_product();
		Thread.sleep(3000);
		shoppingpage.Addtocart();
		Thread.sleep(3000);
		shoppingpage.remove_from_cart();
		
	}
	
	
	
	
	@AfterMethod
	public void tearDown(){
		driver.quit();
	}
	
	

}
